"""The Visual plan's missing-footage list: every narration line that shows a stand-in."""
import unittest
import visual_plan


def piece(kind, a, b, file='S01.mp4'):
    return {'kind': kind, 'start_ms': a, 'end_ms': b, 'file': None if kind == 'uncovered' else file}


class MissingFootageTest(unittest.TestCase):
    def test_lists_only_stand_in_lines_and_joins_neighbours(self):
        data = {'narration_ms': 20000, 'rows': [
            {'span': '002', 'text': 'Daniel Reyes left work.', 'pieces': [piece('photo', 0, 3000)]},
            {'span': '002', 'text': 'He drove down Elm Street,', 'pieces': [piece('base_clip', 3000, 6000)]},
            {'span': '002', 'text': 'past the old gas station.', 'pieces': [piece('weak', 6000, 9000)]},
            {'span': '004', 'text': 'Police found the car.', 'pieces': [piece('match', 9000, 12000, 'B02.mp4')]},
            {'span': '004', 'text': 'It was empty.', 'pieces': [piece('uncovered', 12000, 14000)]}]}
        text = visual_plan.missing_footage(data, 'Reyes case')
        self.assertIn('# Missing footage — Reyes case', text)
        self.assertIn('2 narration passage(s), 8.0s of 20.0s narration (40%)', text)
        self.assertIn('| G01 | 00:00:03,000 → 00:00:09,000 | 6.0s | He drove down Elm Street, past the old gas station. |', text)
        self.assertIn('| G02 | 00:00:12,000 → 00:00:14,000 | 2.0s | It was empty. | nothing |', text)
        self.assertNotIn('Daniel Reyes left work', text)
        self.assertNotIn('Police found the car', text)

    def test_says_so_when_nothing_is_missing(self):
        text = visual_plan.missing_footage({'narration_ms': 5000, 'rows': [
            {'span': '001', 'text': 'x', 'pieces': [piece('match', 0, 5000)]}]})
        self.assertIn('Every narration line has a matching picture.', text)
