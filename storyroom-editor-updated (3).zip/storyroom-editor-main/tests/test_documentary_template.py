"""The shipped templates must be valid: the guide, the worked example and the footage sheet."""
import tempfile
import unittest
from pathlib import Path

import footage_downloader as fd
from document_plan import srt_outline_blocks
from documentary_beats import read_beats
from documentary_script_diagnostics import diagnose

FOLDER = Path(__file__).resolve().parent.parent / 'production-script-templates'
GUIDE = FOLDER / 'documentary-production-script-template.txt'
EXAMPLE = FOLDER / 'Worked_Example_Production_Script.txt'
SHEET = FOLDER / 'Footage_Sheet_Template.md'
LENGTHS = {'S01.mp4': 300000, 'S02.mp4': 180000, 'S03.mp4': 240000, 'S04.mp4': 120000, 'B01.mp4': 15000}


class TemplateTest(unittest.TestCase):
    def setUp(self):
        self.guide = GUIDE.read_text(encoding='utf-8')
        self.example = EXAMPLE.read_text(encoding='utf-8')
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / 'sources').mkdir()
        assets = []
        for i, (name, ms) in enumerate(LENGTHS.items()):
            (self.root / f'sources/{i}.mp4').write_bytes(b'video')
            assets.append({'id': str(i), 'name': name, 'original_name': name, 'kind': 'video',
                           'path': f'sources/{i}.mp4', 'duration': ms / 1000})
        self.project = {'production_script': {'text': self.example}, 'voiceover': {'duration': 56.0}, 'assets': assets}

    def tearDown(self):
        self.tmp.cleanup()

    def test_the_guide_alone_holds_no_beat_and_no_table(self):
        # So the whole guide can be uploaded once section 9 is filled in.
        with self.assertRaises(ValueError):
            read_beats(self.guide)
        self.assertEqual(srt_outline_blocks(self.guide)[0], [])

    def test_the_guide_covers_every_beat_kind(self):
        for letter in 'ABCDEFGH':
            self.assertIn(f'TEMPLATE {letter} —', self.guide)

    def test_the_guide_with_a_script_in_section_9_reads_like_the_script(self):
        cut = self.guide.index('Narration blocks:\n\n| Block | Narration timeline | Wording |\n|---|---|---|\n\nPROJECT:')
        filled = self.guide[:cut] + self.example
        self.assertEqual([b['label'] for b in read_beats(filled)], [b['label'] for b in read_beats(self.example)])
        self.assertEqual(len(srt_outline_blocks(filled)[0]), 9)

    def test_the_worked_example_reads_without_errors(self):
        beats = read_beats(self.example)
        kinds = [b['kind'] for b in beats]
        self.assertEqual(kinds, ['sound_bite'] * 2 + ['narration'] * 5 + ['sound_bite'] + ['narration'] * 4)
        self.assertEqual(beats[0]['pause_ms'], beats[1]['pause_ms'])   # a cold open of two bites
        self.assertEqual(beats[0]['pause_ms'], 0)
        self.assertEqual(beats[7]['pause_ms'], 30000)                  # a bite mid-film
        self.assertEqual(beats[8]['narration_in_ms'], 30000)           # resumes where it paused
        shots = [b['narration_out_ms'] - b['narration_in_ms'] for b in beats if b['kind'] == 'narration']
        self.assertLessEqual(max(shots), 8500)                         # narration shots stay short
        self.assertEqual(beats[-1]['narration_out_ms'], 56000)

    def test_the_worked_example_has_nothing_to_fix(self):
        issues = diagnose(self.project, self.root)['build_issues']
        self.assertEqual(len(issues), 1, issues)
        self.assertIn('reviewed explicitly', issues[0])

    def test_its_narration_table_becomes_the_srt_unchanged(self):
        blocks, problems, notes = srt_outline_blocks(self.example)
        self.assertEqual((problems, notes), ([], []))
        self.assertEqual([b['number'] for b in blocks], list(range(1, 10)))
        self.assertEqual((blocks[0]['start_ms'], blocks[-1]['end_ms']), (0, 56000))

    def test_every_narration_beat_starts_and_ends_on_a_line(self):
        edges = {b['start_ms'] for b in srt_outline_blocks(self.example)[0]} | {56000}
        for beat in read_beats(self.example):
            if beat['kind'] == 'narration':
                self.assertIn(beat['narration_in_ms'], edges, beat['label'])
                self.assertIn(beat['narration_out_ms'], edges, beat['label'])

    def test_its_picture_equals_its_timeline_and_the_runtime_adds_up(self):
        bites = 0
        for beat in read_beats(self.example):
            source = beat['source_out_ms'] - beat['source_in_ms']
            if beat['kind'] == 'narration':
                self.assertEqual(source, beat['narration_out_ms'] - beat['narration_in_ms'], beat['label'])
            else:
                self.assertEqual(source, beat['duration_ms'], beat['label'])
                bites += beat['duration_ms']
        self.assertIn('TOTAL MASTER RUNTIME: 00:01:21,000', self.example)
        self.assertEqual(56000 + bites, 81000)

    def test_no_beat_asks_for_footage_past_its_file(self):
        for beat in read_beats(self.example):
            self.assertLessEqual(beat['source_out_ms'], LENGTHS[beat['source_file']], beat['label'])

    def test_the_footage_sheet_names_every_file_the_script_uses(self):
        sheet = fd.parse_manifest(SHEET.read_text(encoding='utf-8'))
        self.assertEqual(sheet['issues'], [])
        self.assertEqual((sheet['counts']['photos'], sheet['counts']['broll']), (2, 2))
        names = {e['filename'] for e in sheet['entries']}
        self.assertLessEqual({b['source_file'] for b in read_beats(self.example)}, names)
        people = {e['person']: e['role'] for e in sheet['entries'] if e.get('person')}
        self.assertEqual(people, {'Daniel Reyes': 'Victim', 'Linda Reyes': 'Mother', 'Mark Cole': 'Suspect'})


if __name__ == '__main__':
    unittest.main()
