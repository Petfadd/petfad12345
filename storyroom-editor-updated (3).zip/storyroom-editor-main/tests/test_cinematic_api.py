"""Per-slot camera moves, transition locks and undo through the editor's own API."""
import tempfile, unittest
from pathlib import Path
from unittest.mock import patch

import app as server


def scene(sid, asset, f_in, f_out, beat, cue, src='A.mp4', bite=False):
    row = {'script_beat': beat, 'shot_id': cue, 'source_file': src,
           'continuity': 'Documentary beat sound-bite' if bite else f'Documentary beat {beat}'}
    return {'id': sid, 'asset_id': asset, 'frame_in': f_in, 'frame_out': f_out, 'transition': 'cut',
            'approved': False, 'in_s': 0, 'plan_row': row, 'emotion': 'neutral', 'purpose': 'documentary review',
            'focus': 'Documentary footage', 'category': 'general', 'person': '', 'notes': '', 'context_only': False,
            'motion': 'auto', 'srt_blocks': [1, 1]}


def slots():
    return [scene('a' * 16, 'A', 0, 60, '005', 'Srt001'),
            scene('b' * 16, 'A', 60, 120, '005', 'Srt002'),
            scene('c' * 16, 'B', 120, 210, '006', 'Srt003', 'B.mp4'),
            scene('d' * 16, 'C', 210, 360, '007', 'Srt004', 'C.mp4', bite=True),
            scene('e' * 16, 'B', 360, 450, '008', 'Srt005', 'B.mp4')]


class CinematicApi(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.patch = patch.object(server, 'PROJECTS', Path(self.tmp.name)); self.patch.start()
        self.c = server.app.test_client()
        self.pid = self.c.post('/api/projects', json={'title': 'Camera test'}).get_json()['id']
        p = server.load(self.pid); p['edit_mode'] = 'documentary'; p['scenes'] = slots(); server.save(p)

    def tearDown(self):
        self.patch.stop(); self.tmp.cleanup()

    def scenes(self):
        return {s['id']: s for s in server.load(self.pid)['scenes']}

    def test_camera_changes_only_the_selected_slot(self):
        cam = {'zoom_start': 100, 'zoom_end': 110, 'x_start': .4, 'y_start': .5, 'x_end': .5, 'y_end': .5, 'easing': 'linear'}
        r = self.c.patch(f'/api/projects/{self.pid}/scenes/camera', json={'scene_ids': ['c' * 16], 'camera': cam})
        self.assertEqual(r.status_code, 200, r.get_json())
        s = self.scenes()
        self.assertEqual(s['c' * 16]['camera']['zoom_end'], 110.0)
        self.assertEqual(s['c' * 16]['camera']['origin'], 'manual')
        self.assertNotIn('camera', s['a' * 16]); self.assertNotIn('camera', s['e' * 16])
        # Removing it and validation errors.
        bad = self.c.patch(f'/api/projects/{self.pid}/scenes/camera', json={'scene_ids': ['c' * 16], 'camera': {'zoom_end': 250}})
        self.assertEqual(bad.status_code, 400)
        self.c.patch(f'/api/projects/{self.pid}/scenes/camera', json={'scene_ids': ['c' * 16], 'camera': None})
        self.assertNotIn('camera', self.scenes()['c' * 16])

    def test_lock_and_undo(self):
        cam = {'zoom_start': 100, 'zoom_end': 108}
        self.c.patch(f'/api/projects/{self.pid}/scenes/camera', json={'scene_ids': ['a' * 16, 'e' * 16], 'camera': cam, 'locked': True})
        self.assertTrue(self.scenes()['a' * 16]['camera']['locked'])
        self.c.patch(f'/api/projects/{self.pid}/scenes/camera', json={'scene_ids': ['a' * 16], 'locked': False})
        self.assertFalse(self.scenes()['a' * 16]['camera']['locked'])
        self.assertTrue(self.scenes()['e' * 16]['camera']['locked'])
        r = self.c.post(f'/api/projects/{self.pid}/cinematic/undo').get_json()
        self.assertEqual(r['undone']['slots'], 1)
        self.assertTrue(self.scenes()['a' * 16]['camera']['locked'])          # back to before the unlock
        self.c.post(f'/api/projects/{self.pid}/cinematic/undo')
        self.assertNotIn('camera', self.scenes()['a' * 16])                   # back to before the camera
        self.assertEqual(self.c.post(f'/api/projects/{self.pid}/cinematic/undo').status_code, 400)

    def test_locked_transition_survives_auto_and_apply_all(self):
        url = f'/api/projects/{self.pid}/documentary-transitions'
        r = self.c.post(url, json={'action': 'set', 'scene_id': 'c' * 16, 'into': True, 'key': 'fadeblack',
                                   'frames': 20, 'locked': True})
        self.assertEqual(r.status_code, 200, r.get_json())
        s = self.scenes()
        # "Into" slot c is the cut after slot b.
        self.assertEqual(s['b' * 16]['transition'], 'fadeblack')
        self.assertEqual(s['b' * 16]['transition_handle_frames'], 20)
        self.assertTrue(s['b' * 16]['transition_locked'])
        self.c.post(url, json={'action': 'all', 'key': 'dissolve'})
        self.c.post(url, json={'action': 'auto', 'style': 'expressive'})
        self.c.post(url, json={'action': 'clear'})
        self.assertEqual(self.scenes()['b' * 16]['transition'], 'fadeblack')
        cuts = {c['scene_id']: c for c in self.c.get(url).get_json()['cuts']}
        self.assertTrue(cuts['b' * 16]['locked'])
        # Undo walks back through clear, auto and all, to the locked fade.
        for _ in range(3):
            self.c.post(f'/api/projects/{self.pid}/cinematic/undo')
        self.assertEqual(self.scenes()['b' * 16]['transition'], 'fadeblack')

    def test_whip_pan_is_in_the_library(self):
        import transitions
        self.assertIn('whip', transitions.LIBRARY)
        self.assertEqual(transitions.from_cut_action('WHIP PAN'), 'whip')

    def test_rebuild_keeps_cameras_and_locked_transitions(self):
        old = slots(); old[2]['camera'] = {'zoom_start': 100, 'zoom_end': 112, 'x_start': .5, 'y_start': .5,
                                           'x_end': .5, 'y_end': .5, 'easing': 'linear', 'origin': 'manual', 'locked': True}
        old[1].update(transition='fadeblack', transition_handle_frames=20, transition_locked=True)
        new = slots()
        for s in new:
            s['id'] = s['id'][::-1].replace(s['id'][0], 'f', 1)               # a rebuild makes new ids
        server._carry_cinematic(old, new)
        self.assertEqual(new[2]['camera']['zoom_end'], 112)
        self.assertEqual(new[1]['transition'], 'fadeblack'); self.assertTrue(new[1]['transition_locked'])
        self.assertNotIn('camera', new[0])


if __name__ == '__main__':
    unittest.main()


class PhotoMotionApi(unittest.TestCase):
    def setUp(self):
        from PIL import Image
        self.tmp = tempfile.TemporaryDirectory()
        self.patch = patch.object(server, 'PROJECTS', Path(self.tmp.name)); self.patch.start()
        self.c = server.app.test_client()
        self.pid = self.c.post('/api/projects', json={'title': 'Photo test'}).get_json()['id']
        root = Path(self.tmp.name) / self.pid; (root / 'people').mkdir(exist_ok=True)
        Image.new('RGB', (300, 400), 'teal').save(root / 'people' / 'jane.jpg')
        p = server.load(self.pid)
        p['people'] = [{'id': 'p1', 'name': 'Jane Doe', 'role': 'Victim', 'photo': {'path': 'people/jane.jpg', 'uploaded': 1}}]
        server.save(p)

    def tearDown(self):
        self.patch.stop(); self.tmp.cleanup()

    def test_setting_and_layers(self):
        bad = self.c.patch(f'/api/projects/{self.pid}', json={'person_overlay_settings': {'photo_motion': 'spin'}})
        self.assertEqual(bad.status_code, 400)
        ok = self.c.patch(f'/api/projects/{self.pid}', json={'person_overlay_settings': {'photo_motion': 'zoom_in'}})
        self.assertEqual(ok.status_code, 200, ok.get_json())
        photo = self.c.get(f'/api/projects/{self.pid}/people/p1/card.png?layer=photo')
        label = self.c.get(f'/api/projects/{self.pid}/people/p1/card.png?layer=label')
        whole = self.c.get(f'/api/projects/{self.pid}/people/p1/card.png')
        self.assertEqual((photo.status_code, photo.mimetype), (200, 'image/jpeg'))
        self.assertEqual((label.status_code, label.mimetype), (200, 'image/png'))
        self.assertEqual(whole.status_code, 200)
        import person_overlays as po
        self.assertIsNotNone(po.motion_camera(server.load(self.pid)['people'][0], po.settings(server.load(self.pid))))
