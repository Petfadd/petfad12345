"""B-roll from the sheet goes on the line that names what it shows."""
import unittest

import visual_plan as vp


class WordsTest(unittest.TestCase):
    def test_srt_spellings_still_match(self):
        line = vp.narration_tokens('at Sunset Crossing Apartments off Beach Nut Street')
        item = vp.tokens('Beechnut Street sign')
        self.assertIn(vp._stem('beechnut'), vp.shared_words(line, item))

    def test_near_is_one_letter_only(self):
        self.assertTrue(vp._near('beachnut', 'beechnut'))
        self.assertTrue(vp._near('thompson', 'thomson'))
        self.assertFalse(vp._near('house', 'horse'))      # five letters: exact only
        self.assertFalse(vp._near('car', 'cat'))          # short words must match exactly
        self.assertFalse(vp._near('sunset', 'sunrise'))


if __name__ == '__main__':
    unittest.main()
